package com.example.car_diary;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "CarDiary.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_STORE = "key_value_store";
    private static final String COL_KEY = "data_key";
    private static final String COL_VALUE = "data_value";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_STORE + " (" +
                COL_KEY + " TEXT PRIMARY KEY, " +
                COL_VALUE + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STORE);
        onCreate(db);
    }

    // Inserts a new key-value pair, or overwrites if the key already exists
    public void saveData(String key, String value) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_KEY, key);
        values.put(COL_VALUE, value);

        db.replace(TABLE_STORE, null, values);
        db.close();
    }

    // Retrieves the JSON string for a given key
    public String getData(String key) {
        SQLiteDatabase db = this.getReadableDatabase();
        String result = null;

        Cursor cursor = db.query(TABLE_STORE, new String[]{COL_VALUE},
                COL_KEY + "=?", new String[]{key},
                null, null, null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                result = cursor.getString(0);
            }
            cursor.close();
        }
        db.close();
        return result;
    }
}