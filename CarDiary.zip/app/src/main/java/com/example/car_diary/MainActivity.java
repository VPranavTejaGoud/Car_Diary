package com.example.car_diary;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraImageUri;

    private final ActivityResultLauncher<Intent> filePickerLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (filePathCallback == null) {
                            return;
                        }

                        Uri[] results = null;

                        if (result.getResultCode() == Activity.RESULT_OK) {
                            if (cameraImageUri != null) {
                                results = new Uri[]{cameraImageUri};
                            } else if (result.getData() != null) {
                                Intent data = result.getData();

                                if (data.getClipData() != null) {
                                    int count = data.getClipData().getItemCount();
                                    results = new Uri[count];

                                    for (int i = 0; i < count; i++) {
                                        results[i] = data.getClipData().getItemAt(i).getUri();
                                    }
                                } else if (data.getData() != null) {
                                    results = new Uri[]{data.getData()};
                                }
                            }
                        }

                        filePathCallback.onReceiveValue(results);
                        filePathCallback = null;
                        cameraImageUri = null;
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        WebView webView = findViewById(R.id.webView);

        // Force the WebView background to match your splash screen instantly to avoid white flash
        webView.setBackgroundColor(Color.parseColor("#0D0D11"));

        // Intercept Android Back Button
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // Ask the HTML if it handled the back action (e.g., closing a modal)
                webView.evaluateJavascript("javascript:handleBackButton()", result -> {
                    // JS returns "true" if it closed a screen, "false" if we are at the root
                    if (!"true".equals(result)) {
                        // Disable this interceptor temporarily and let the app close normally
                        setEnabled(false);
                        getOnBackPressedDispatcher().onBackPressed();
                        setEnabled(true);
                    }
                });
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("tel:")) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                    return true; // Tells WebView we handled the phone call natively
                }
                return false; // Loads normal web links inside the WebView
            }
        });
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);

        // Bind the JavaScript interface to the WebView to talk to SQLite and WhatsApp
        webView.addJavascriptInterface(new WebAppInterface(), "AppBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {

                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }

                MainActivity.this.filePathCallback = callback;

                if (params.isCaptureEnabled()) {
                    Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                    if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Images.Media.DISPLAY_NAME, "CarDiary_" + System.currentTimeMillis() + ".jpg");
                        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");

                        cameraImageUri = getContentResolver().insert(
                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                values);

                        if (cameraImageUri != null) {
                            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraImageUri);
                            cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

                            try {
                                filePickerLauncher.launch(cameraIntent);
                                return true;
                            } catch (Exception e) {
                                cameraImageUri = null;
                            }
                        }
                    }
                }

                try {
                    filePickerLauncher.launch(params.createIntent());
                    return true;
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    // Single unified inner class handling JavaScript calls from index.html
    public class WebAppInterface {

        @JavascriptInterface
        public void saveData(String key, String data) {
            dbHelper.saveData(key, data);
        }

        @JavascriptInterface
        public String getData(String key) {
            return dbHelper.getData(key);
        }

        @JavascriptInterface
        public void shareToWhatsApp(String messageText, String[] base64Images) {
            try {
                Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                intent.setType("image/*");
                intent.setPackage("com.whatsapp"); // Targets WhatsApp directly

                intent.putExtra(Intent.EXTRA_TEXT, messageText);

                ArrayList<Uri> imageUris = new ArrayList<>();
                File cacheDir = new File(getCacheDir(), "shared_images");
                if (!cacheDir.exists()) cacheDir.mkdirs();

                for (int i = 0; i < base64Images.length; i++) {
                    String base64Str = base64Images[i];
                    if (base64Str != null && base64Str.contains(",")) {
                        base64Str = base64Str.split(",")[1];
                    }
                    byte[] decodedBytes = android.util.Base64.decode(base64Str, android.util.Base64.DEFAULT);

                    File imageFile = new File(cacheDir, "car_share_" + i + ".jpg");
                    FileOutputStream fos = new FileOutputStream(imageFile);
                    fos.write(decodedBytes);
                    fos.flush();
                    fos.close();

                    Uri photoUri = androidx.core.content.FileProvider.getUriForFile(
                            MainActivity.this,
                            getPackageName() + ".fileprovider",
                            imageFile
                    );
                    imageUris.add(photoUri);
                }

                intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, imageUris);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                startActivity(intent);
            } catch (Exception e) {
                // Fallback if WhatsApp is not installed or sharing fails
                Intent fallbackIntent = new Intent(Intent.ACTION_SEND);
                fallbackIntent.setType("text/plain");
                fallbackIntent.putExtra(Intent.EXTRA_TEXT, messageText);
                startActivity(Intent.createChooser(fallbackIntent, "Share Car Details"));
            }
        }
    }
}